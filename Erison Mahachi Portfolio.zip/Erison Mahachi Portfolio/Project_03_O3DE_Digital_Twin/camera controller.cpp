#include "CameraController.h"

void CameraController::Update(float deltaTime)
{
    ProcessInput(deltaTime);
    UpdateCameraTransform();
}

void CameraController::ProcessInput(float deltaTime)
{
    if (m_moveForward)
    {
        m_position +=
            m_forward *
            m_speed *
            deltaTime;
    }
}