class Agent:

    def __init__(self, app):

        self.x = 0
        self.y = 0
        self.z = 0

    def update(self):

        self.x += 0.05

    def get_position(self):

        return {
            "x": self.x,
            "y": self.y,
            "z": self.z
        }