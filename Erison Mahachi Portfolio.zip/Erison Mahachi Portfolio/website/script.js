/* ==========================================================================
   Smooth Scrolling for Anchor Links
   ========================================================================== */

// Select all anchor tags that have an href attribute starting with "#"
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    
    anchor.addEventListener('click', function(e) {
        // Prevent the default instant-jump behavior
        e.preventDefault();

        // Get the target element using the href attribute value
        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        // Safely scroll to the element if it exists on the page
        if (targetElement) {
            targetElement.scrollIntoView({
                behavior: 'smooth',
                block: 'start' // Aligns the top of the element to the top of the viewport
            });
        }
    });

});